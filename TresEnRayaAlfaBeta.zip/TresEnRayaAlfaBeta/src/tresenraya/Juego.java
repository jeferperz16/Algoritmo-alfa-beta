package tresenraya;

import java.util.Scanner;

/**
 * Controla el flujo de la partida entre el humano (X) y la IA (O).
 */
public class Juego {

    private final Tablero tablero = new Tablero();
    private final AlfaBeta ia = new AlfaBeta(Ficha.O);
    private final Scanner sc = new Scanner(System.in);

    public void iniciar() {
        System.out.println("=== TRES EN RAYA con poda Alfa-Beta ===");
        System.out.println("Tú eres X, la computadora es O.");
        System.out.print("¿Quieres empezar tú? (s/n): ");
        boolean turnoHumano = sc.nextLine().trim().equalsIgnoreCase("s");

        tablero.imprimir();

        while (!tablero.juegoTerminado()) {
            if (turnoHumano) {
                turnoHumano();
            } else {
                turnoIA();
            }
            tablero.imprimir();
            turnoHumano = !turnoHumano;
        }

        mostrarResultado();
        sc.close();
    }

    private void turnoHumano() {
        while (true) {
            System.out.print("Tu turno (X). Ingresa fila y columna (1-3), ej: 2 3 -> ");
            try {
                String[] partes = sc.nextLine().trim().split("\\s+");
                int fila = Integer.parseInt(partes[0]) - 1;
                int col = Integer.parseInt(partes[1]) - 1;

                if (!tablero.esPosicionValida(fila, col)) {
                    System.out.println("Posición fuera del tablero.");
                } else if (!tablero.estaLibre(fila, col)) {
                    System.out.println("Esa casilla ya está ocupada.");
                } else {
                    tablero.colocar(fila, col, Ficha.X);
                    return;
                }
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                System.out.println("Entrada inválida. Usa el formato: fila columna");
            }
        }
    }

    private void turnoIA() {
        int[] jugada = ia.mejorMovimiento(tablero);
        tablero.colocar(jugada[0], jugada[1], Ficha.O);
        System.out.println("La computadora juega en fila " + (jugada[0] + 1)
                + ", columna " + (jugada[1] + 1)
                + "  (nodos explorados: " + ia.getNodosExplorados() + ")");
    }

    private void mostrarResultado() {
        Ficha ganador = tablero.obtenerGanador();
        if (ganador == Ficha.X) {
            System.out.println("¡Ganaste!");
        } else if (ganador == Ficha.O) {
            System.out.println("Ganó la computadora.");
        } else {
            System.out.println("¡Empate!");
        }
    }
}