


package tresenraya;

/**
 * Representa el tablero 3x3 y las reglas básicas del juego.
 */
public class Tablero {

    private final Ficha[][] celdas = new Ficha[3][3];

    public Tablero() {
        reiniciar();
    }

    public final void reiniciar() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                celdas[i][j] = Ficha.VACIO;
            }
        }
    }

    public boolean esPosicionValida(int fila, int col) {
        return fila >= 0 && fila < 3 && col >= 0 && col < 3;
    }

    public boolean estaLibre(int fila, int col) {
        return celdas[fila][col] == Ficha.VACIO;
    }

    public void colocar(int fila, int col, Ficha ficha) {
        celdas[fila][col] = ficha;
    }

    public void quitar(int fila, int col) {
        celdas[fila][col] = Ficha.VACIO;
    }

    public boolean estaLleno() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (celdas[i][j] == Ficha.VACIO) return false;
            }
        }
        return true;
    }

    /** Devuelve X u O si alguien ganó, o VACIO si aún no hay ganador. */
    public Ficha obtenerGanador() {
        // Filas y columnas
        for (int i = 0; i < 3; i++) {
            if (celdas[i][0] != Ficha.VACIO
                    && celdas[i][0] == celdas[i][1] && celdas[i][1] == celdas[i][2]) {
                return celdas[i][0];
            }
            if (celdas[0][i] != Ficha.VACIO
                    && celdas[0][i] == celdas[1][i] && celdas[1][i] == celdas[2][i]) {
                return celdas[0][i];
            }
        }
        // Diagonales
        if (celdas[1][1] != Ficha.VACIO) {
            if (celdas[0][0] == celdas[1][1] && celdas[1][1] == celdas[2][2]) return celdas[1][1];
            if (celdas[0][2] == celdas[1][1] && celdas[1][1] == celdas[2][0]) return celdas[1][1];
        }
        return Ficha.VACIO;
    }

    public boolean juegoTerminado() {
        return obtenerGanador() != Ficha.VACIO || estaLleno();
    }

    public void imprimir() {
        System.out.println();
        for (int i = 0; i < 3; i++) {
            System.out.println(" " + celdas[i][0].getSimbolo()
                    + " | " + celdas[i][1].getSimbolo()
                    + " | " + celdas[i][2].getSimbolo());
            if (i < 2) System.out.println("---+---+---");
        }
        System.out.println();
    }
}