
 package tresenraya;

/**
 * Representa el contenido de una casilla del tablero.
 */
public enum Ficha {
    X('X'),
    O('O'),
    VACIO(' ');

    private final char simbolo;

    Ficha(char simbolo) {
        this.simbolo = simbolo;
    }

    public char getSimbolo() {
        return simbolo;
    }

    /** Devuelve la ficha contraria (X <-> O). */
    public Ficha oponente() {
        if (this == X) return O;
        if (this == O) return X;
        return VACIO;
    }
}