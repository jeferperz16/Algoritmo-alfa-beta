package tresenraya;

/**
 * Jugador artificial basado en Minimax con poda Alfa-Beta.
 *
 * - La IA es el jugador MAX.
 * - El humano es el jugador MIN.
 *
 * Utilidad de los nodos terminales:
 *   Gana la IA      -> 10 - profundidad   (prefiere ganar rápido)
 *   Gana el humano  -> profundidad - 10   (prefiere perder lento)
 *   Empate          -> 0
 */
public class AlfaBeta {

    private final Ficha ia;
    private final Ficha humano;
    private int nodosExplorados;

    public AlfaBeta(Ficha ia) {
        this.ia = ia;
        this.humano = ia.oponente();
    }

    public int getNodosExplorados() {
        return nodosExplorados;
    }

    /** Evalúa todas las jugadas posibles y devuelve la mejor como {fila, columna}. */
    public int[] mejorMovimiento(Tablero tablero) {
        int mejorValor = Integer.MIN_VALUE;
        int[] mejorJugada = {-1, -1};
        nodosExplorados = 0;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tablero.estaLibre(i, j)) {
                    tablero.colocar(i, j, ia);                       // hacer jugada
                    int valor = alfaBeta(tablero, 1, false,
                            Integer.MIN_VALUE, Integer.MAX_VALUE);
                    tablero.quitar(i, j);                            // deshacer jugada

                    if (valor > mejorValor) {
                        mejorValor = valor;
                        mejorJugada[0] = i;
                        mejorJugada[1] = j;
                    }
                }
            }
        }
        return mejorJugada;
    }

    /**
     * @param profundidad nivel actual del árbol de búsqueda
     * @param esMax       true = turno de la IA (maximiza), false = humano (minimiza)
     * @param alfa        mejor valor garantizado para MAX
     * @param beta        mejor valor garantizado para MIN
     */
    private int alfaBeta(Tablero tablero, int profundidad, boolean esMax, int alfa, int beta) {
        nodosExplorados++;

        // Casos base
        Ficha ganador = tablero.obtenerGanador();
        if (ganador == ia)      return 10 - profundidad;
        if (ganador == humano)  return profundidad - 10;
        if (tablero.estaLleno()) return 0;

        if (esMax) {
            int mejor = Integer.MIN_VALUE;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (tablero.estaLibre(i, j)) {
                        tablero.colocar(i, j, ia);
                        int valor = alfaBeta(tablero, profundidad + 1, false, alfa, beta);
                        tablero.quitar(i, j);

                        mejor = Math.max(mejor, valor);
                        alfa = Math.max(alfa, mejor);
                        if (beta <= alfa) {
                            return mejor;   // PODA BETA
                        }
                    }
                }
            }
            return mejor;
        } else {
            int mejor = Integer.MAX_VALUE;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (tablero.estaLibre(i, j)) {
                        tablero.colocar(i, j, humano);
                        int valor = alfaBeta(tablero, profundidad + 1, true, alfa, beta);
                        tablero.quitar(i, j);

                        mejor = Math.min(mejor, valor);
                        beta = Math.min(beta, mejor);
                        if (beta <= alfa) {
                            return mejor;   // PODA ALFA
                        }
                    }
                }
            }
            return mejor;
        }
    }
}